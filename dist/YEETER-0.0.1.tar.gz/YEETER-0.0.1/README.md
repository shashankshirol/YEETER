#YEETER

A python package to print YEET wherever you call the function.
Uses internet to get ASCII art of YEET when you use FancyYeeter.
